V = 1
V0 = $(V:0=)
Q1 = $(V:1=)
Q = $(Q1:0=@)
ECHO1 = $(V:1=@:)
ECHO = $(ECHO1:0=@echo)
override MFLAGS := $(filter-out -j%,$(MFLAGS))
ext_build_dir = .bundle/gems/rbs-3.4.0

ruby = $(topdir)/miniruby -I'$(topdir)' -I'$(top_srcdir)/lib' \
       -I'$(extout)/$(arch)' -I'$(extout)/common'
RUBY = $(ruby)
extensions = .bundle/gems/rbs-3.4.0/ext/rbs_extension/.
EXTOBJS = dmyext.o
EXTLIBS =
EXTSO =
EXTLDFLAGS =
EXTINITS =
SUBMAKEOPTS = DLDOBJS="$(EXTOBJS) $(EXTENCS)" EXTOBJS= \
	      EXTSOLIBS="$(EXTLIBS)" LIBRUBY_SO_UPDATE=$(LIBRUBY_EXTS) \
	      EXTLDFLAGS="$(EXTLDFLAGS)" EXTINITS="$(EXTINITS)" \
	      UPDATE_LIBRARIES="$(UPDATE_LIBRARIES)" SHOWFLAGS=
NOTE_MESG = $(RUBY) $(top_srcdir)/tool/lib/colorize.rb skip
NOTE_NAME = $(RUBY) $(top_srcdir)/tool/lib/colorize.rb fail
RM = rm -f
RMDIRS = rmdir -p
RMDIR = rmdir
RMALL = rm -fr
MESSAGE_BEGIN = @for line in
MESSAGE_END = ; do echo "$$line"; done

all: $(extensions:/.=/all)
all: note
install: $(extensions:/.=/install)
install: note
static: $(extensions:/.=/static)
static: note
install-so: $(extensions:/.=/install-so)
install-so: note
install-rb: $(extensions:/.=/install-rb)
install-rb: note
clean: $(extensions:/.=/clean)
distclean: $(extensions:/.=/distclean)
realclean: $(extensions:/.=/realclean)

clean:
	-$(Q)$(RM) ext/extinit.o
distclean:
	-$(Q)$(RM) ext/extinit.c

ruby33: $(extensions:/.=/all)
all static: ruby33
ruby33: $(EXTOBJS)
ruby33:
	$(Q)$(MAKE) $(MFLAGS) $(SUBMAKEOPTS) $@
libencs:
	$(Q)$(MAKE) -f enc.mk V=$(V) $@

.bundle/gems/rbs-3.4.0/ext/rbs_extension/all:
	$(Q)cd $(@D) && exec $(MAKE) $(MFLAGS) V=$(V) $(@F)
.bundle/gems/rbs-3.4.0/ext/rbs_extension/install:
	$(Q)cd $(@D) && exec $(MAKE) $(MFLAGS) V=$(V) $(@F)
.bundle/gems/rbs-3.4.0/ext/rbs_extension/static:
	$(Q)cd $(@D) && exec $(MAKE) $(MFLAGS) V=$(V) $(@F)
.bundle/gems/rbs-3.4.0/ext/rbs_extension/install-so:
	$(Q)cd $(@D) && exec $(MAKE) $(MFLAGS) V=$(V) $(@F)
.bundle/gems/rbs-3.4.0/ext/rbs_extension/install-rb:
	$(Q)cd $(@D) && exec $(MAKE) $(MFLAGS) V=$(V) $(@F)
.bundle/gems/rbs-3.4.0/ext/rbs_extension/clean: clean-local
	$(Q)cd $(@D) && exec $(MAKE) $(MFLAGS) V=$(V) $(@F)
.bundle/gems/rbs-3.4.0/ext/rbs_extension/distclean: clean-local
	$(Q)cd $(@D) && exec $(MAKE) $(MFLAGS) V=$(V) $(@F)
	$(Q)$(RM) $(ext_build_dir)/exts.mk
	$(Q)$(RMDIRS) -p $(@D)
.bundle/gems/rbs-3.4.0/ext/rbs_extension/realclean: clean-local
	$(Q)cd $(@D) && exec $(MAKE) $(MFLAGS) V=$(V) $(@F)
	$(Q)$(RM) $(ext_build_dir)/exts.mk
	$(Q)$(RMDIRS) -p $(@D)

clean-local:
	$(Q)$(RM) $(ext_build_dir)/*~ $(ext_build_dir)/*.bak $(ext_build_dir)/core

extso:
	@echo EXTSO=$(EXTSO)

note:
