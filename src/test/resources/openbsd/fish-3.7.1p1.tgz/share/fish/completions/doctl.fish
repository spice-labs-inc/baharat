doctl completion fish | source
