oc completion fish | source
