op completion fish | source
