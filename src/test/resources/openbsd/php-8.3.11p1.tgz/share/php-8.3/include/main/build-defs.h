/*
   +----------------------------------------------------------------------+
   | Copyright (c) The PHP Group                                          |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | https://www.php.net/license/3_01.txt                                 |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig Sæther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

#define CONFIGURE_COMMAND " './configure'  '--disable-rpath' '--disable-static' '--enable-shared' '--program-suffix=-8.3' '--with-config-file-path=/etc' '--with-config-file-scan-dir=/etc/php-8.3' '--with-layout=GNU' '--with-external-pcre' '--with-pcre-jit=no' '--with-pear=/usr/local/share/php-8.3' '--with-pic' '--with-readline' '--without-valgrind' '--with-mysql-sock=/var/run/mysql/mysql.sock' '--enable-opcache' '--with-gettext=/usr/local' '--with-iconv=/usr/local' '--with-openssl' '--with-password-argon2=/usr/local' '--with-sodium=/usr/local' '--with-zlib' '--enable-bcmath' '--enable-calendar' '--enable-ctype' '--enable-exif' '--enable-ftp' '--enable-mbstring' '--enable-phar' '--enable-session' '--enable-sockets' '--enable-sysvmsg' '--enable-sysvsem' '--enable-sysvshm' '--enable-xml' '--with-capstone' '--enable-cli' '--enable-fpm' '--with-fpm-user=www' '--with-fpm-group=www' '--enable-cgi' '--enable-phpdbg' '--with-apxs2=/usr/local/sbin/apxs' '--with-bz2=shared,/usr/local' '--with-curl=shared,/usr/local' '--enable-dba=shared' '--with-gdbm=/usr/local' '--with-enchant=shared,/usr/local' '--with-external-gd' '--enable-gd=shared' '--with-freetype=/usr/X11R6' '--with-jpeg=/usr/local' '--with-webp=/usr/local' '--with-xpm=/usr/X11R6' '--with-gmp=shared,/usr/local' '--with-imap=shared,/usr/local' '--with-imap-ssl' '--enable-intl=shared' '--with-ldap=shared,/usr/local' '--with-mysqli=shared' '--with-iodbc=shared,/usr/local' '--enable-pcntl=shared' '--with-pdo-dblib=shared,/usr/local' '--with-pdo-mysql=shared' '--with-pdo-odbc=shared,iODBC,/usr/local' '--with-pdo-pgsql=shared,/usr/local' '--with-pdo-sqlite=shared,/usr/local' '--with-pgsql=shared,/usr/local' '--with-pspell=shared,/usr/local' '--enable-shmop=shared,/usr/local' '--with-snmp=shared,/usr/local' '--enable-soap=shared,/usr/local' '--with-sqlite3=shared,/usr/local' '--with-tidy=shared,/usr/local' '--with-xsl=shared' '--enable-dom' '--with-zip=shared' '--prefix=/usr/local' '--sysconfdir=/etc' '--mandir=/usr/local/man' '--infodir=/usr/local/info' '--localstatedir=/var' '--disable-silent-rules' '--disable-gtk-doc' 'CFLAGS=-O2 -pipe -g -I/usr/local/include -pthread'"
#define PHP_ODBC_CFLAGS	"-I/usr/local/include"
#define PHP_ODBC_LFLAGS		""
#define PHP_ODBC_LIBS		"-L/usr/local/lib -liodbc -liodbcinst"
#define PHP_ODBC_TYPE		"iodbc"
#define PHP_OCI8_DIR			""
#define PHP_OCI8_ORACLE_VERSION		""
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PEAR_INSTALLDIR         "/usr/local/share/php-8.3"
#define PHP_INCLUDE_PATH	".:/usr/local/lib/php"
#define PHP_EXTENSION_DIR       "/usr/local/lib/php-8.3/modules"
#define PHP_PREFIX              "/usr/local"
#define PHP_BINDIR              "/usr/local/bin"
#define PHP_SBINDIR             "/usr/local/sbin"
#define PHP_MANDIR              "/usr/local/man"
#define PHP_LIBDIR              "/usr/local/lib/php"
#define PHP_DATADIR             "/usr/local/share/php"
#define PHP_SYSCONFDIR          "/etc"
#define PHP_LOCALSTATEDIR       "/var"
#define PHP_CONFIG_FILE_PATH    "/etc"
#define PHP_CONFIG_FILE_SCAN_DIR    "/etc/php-8.3"
#define PHP_SHLIB_SUFFIX        "so"
#define PHP_SHLIB_EXT_PREFIX    ""
